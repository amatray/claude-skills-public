---
name: voice-update-idb
description: "Use when the user wants the corrections they agreed to moved into their writing guides: 'update my guide', 'update my voice guide', 'update the voice guidelines', 'apply my corrections', 'promote the corrections I agreed to', or 'yes, put that in the guide' after a correction was recorded. Produces the changed guide, a dated copy of the guide as it was, and an updated corrections file."
metadata:
  version: "1.0"
---

# Update my guide

Move the corrections I have agreed to into my writing guides, and nothing else.

1. **Find my voice folder**: the folder that holds `CORE_VOICE.md`. Its path is in the section "My writing voice" of my personal `CLAUDE.md`. If you cannot find it, ask "Where is your voice folder?" and stop.
2. **Read `log_voice_adjustments.md`.** Take the entries whose status is "agreed, not yet in a guide". For entries marked "proposed, waiting for my yes", list them and ask me; without a yes, leave them. Ignore every other entry. If nothing is agreed, say so and stop.
3. **Keep the old version.** Before changing a guide, copy it into a `history` folder inside the voice folder, with today's date in the file name.
4. **Make the smallest change that carries the correction.** If a line of the guide says something the correction contradicts or narrows, replace or narrow that line; do not add a second line beside it. Add nothing the entry does not say: no new situation, no threshold, no email taken from anywhere but the entry.
5. **Put it in the right guide.** A correction that holds for every reader goes in `CORE_VOICE.md`. Any other goes in the guide for that kind of document.
6. **Close the entry.** Set its status to: in which guide, since which date, the line as it now reads, and the readers it applies to.
7. **Show me**: for each guide, the line before and the line after; the path of the copy you kept; and any entry you skipped, with the reason.

---
name: voice-learn-idb
description: "Use when the user has changed a draft Claude wrote and wants the change remembered: 'learn from my edits', 'compare my edits', 'analyze my edits', 'I changed your draft', 'here is what I actually sent', or a corrected version pasted back after a draft. Produces one entry in the corrections file of the voice folder and a short verdict on each change. It does not change any writing guide."
metadata:
  version: "1.0"
---

# Learn from my edits

Record what I changed in a draft you wrote, so the change is not lost.

This skill never edits a guide. A guide changes only through `voice-update-idb`, after I have agreed. The reason: asked to learn from one corrected date, an unaided run added new rules to two guides.

1. **Find the two versions**: your draft, and the version I sent. Look in this conversation first, then in the files I name. If one is missing, ask me to paste it. Do not rebuild either from memory.
2. **Find my voice folder**: the folder that holds `CORE_VOICE.md`. Its path is in the section "My writing voice" of my personal `CLAUDE.md`. If you cannot find it, ask "Where is your voice folder?" and stop.
3. **Sort each change into one of three kinds.**
   - **One-off**: a fact (a date, a name, a number) or a choice that belongs to this document only.
   - **Already covered**: a guide already says it and the draft did not follow it. Quote the line of the guide.
   - **Would come back**: a choice about how I write that would apply to another document. Say for which readers. One example is thin evidence: do not turn it into a threshold or a new situation.
4. **Get my reason for each change that would come back.** If I gave one in this conversation, use it in my words. If I did not, do not write one for me: offer your best guess in one line and ask me to confirm or correct it. Ask once, for all such changes together. One-offs and changes already covered need no reason.
5. **Add one entry to `corrections.md`**, in the format that file already uses. Mark each reason as mine, or as your guess, not confirmed. Status is "nothing to change" for the first two kinds and "proposed, waiting for my yes" for the third.
6. **Tell me, in five lines at most**: what changed, which kind each change is, and for a change that would come back, the exact line you would add or replace and in which guide. Ask me yes or no.
7. **If I say yes**, set the status to "agreed, not yet in a guide" and tell me to say "update my guide" when I am ready. Leave the guides as they are.

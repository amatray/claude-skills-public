# Corrections

Every time I change a draft Claude wrote for me, one entry goes here. An entry is a record. Claude does not read this file when drafting; a draft changes only when a guide changes.

## Entries

### [date]

- **Context:** [kind of document, and the reader]
- **Rejected:** "[what Claude wrote]"
- **Approved:** "[what I sent]"
- **Reason:** [why, in terms of the reader] (mine / Claude's guess, not confirmed)
- **Recurs?** [one-off / would recur for (which readers)]
- **Status:** [nothing to change / proposed, waiting for my yes / agreed, not yet in a guide / in (guide) since (date): (the line), applies to (readers)]

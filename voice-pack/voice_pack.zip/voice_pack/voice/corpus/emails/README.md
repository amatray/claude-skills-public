# My sample emails

Emails I sent, one per file, written without AI. Only my own text: the quoted earlier messages are removed.

Claude fills this table and marks each row "guessed". I correct it, and the corrected rows are marked "confirmed".

| File | To | Relationship (senior, peer, junior, outside the Bank) | Purpose | Written without AI | Status |
|---|---|---|---|---|---|
| `01.txt` | | | | | |

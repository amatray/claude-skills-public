# House style: [Macroeconomic Assessment / Country Diagnostic]

Copy this file once per report and rename the copy, for example `MACRO_ASSESSMENT_STYLE.md`.

This guide is different from the others in the folder. The voice is the institution's, not mine. It is built from approved final reports, not from my drafts.

## The reports this guide is built from

Only reports I am allowed to open with Claude under the Bank's rules.

| Report | Country and year | Why it is a good model |
|---|---|---|
| | | |

## Section by section

| Section | What the section has to do | Usual length | How a number is stated (unit, year, source) | Model passage (report, page) |
|---|---|---|---|---|
| | | | | |

## Conventions

- **Terms:** [the words the report uses for recurring concepts, and the ones it avoids]
- **Abbreviations:** [which are spelled out, and where]
- **Stating a judgement:** [how firmly a risk or an outlook is worded]
- **Other institutions:** [how the views of the International Monetary Fund or the World Bank are reported]

## What Claude drafts and what I supply

- Claude drafts description: what a series did, what a table shows, in the wording of the model passages.
- I supply every judgement: the risk call, the priority, the conclusion of a section. Claude does not propose one unless I ask, and marks it as a proposal when it does.
- Every number in a draft carries its source and year, so I can check it.

## What reviewers send back

[Remarks that come back from review more than once. For each: the passage as drafted, the passage as approved, and the reason.]

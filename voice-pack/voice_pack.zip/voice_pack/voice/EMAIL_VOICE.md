# How [your name] writes emails

Loaded in every session, after `CORE_VOICE.md`. Built from my own sent emails in `corpus/emails`.

## Readers

One row per kind of person I write to. Rows I never use are deleted.

| Reader | Greeting | Length | How I make the request | Sign-off | Sample files |
|---|---|---|---|---|---|
| My director or Regional Economic Advisor | | | | | |
| Colleagues in my own team | | | | | |
| A sector division, when I need their contribution | | | | | |
| The country office | | | | | |
| A government counterpart (ministry, central bank) | | | | | |

If I ask for an email without saying which reader it is for, ask me.

## Situations

One card for each situation I write in often. A card exists only if I have a real email for it. Copy its length and its order before its words.

### Asking a division for a contribution

- **Use when:** [for example, opening a request for a sector note or a data series]
- **Reader:** [which row of the table above]
- **The email, exactly as sent:**

> [paste, unchanged]

- **Why it is written this way:** [the reasoning: what comes first and why, what I left out, how I name the deadline]
- **Belongs to that day only:** [names, dates, figures and promises that must not be reused]

### Reminding someone who is late

- **Use when:**
- **Reader:**
- **The email, exactly as sent:**

> 

- **Why it is written this way:**
- **Belongs to that day only:**

### Sending a draft up for review

- **Use when:**
- **Reader:**
- **The email, exactly as sent:**

> 

- **Why it is written this way:**
- **Belongs to that day only:**

### Answering a government counterpart

- **Use when:**
- **Reader:**
- **The email, exactly as sent:**

> 

- **Why it is written this way:**
- **Belongs to that day only:**

## My reasons

The habits behind the cards, each with its reason, so they can be applied to a situation that has no card.

- I [habit], because [reason]. This holds for [which readers].

## No sample yet

[Situations my emails do not cover, for example turning down a request, or a first message to someone I have never met. For these, ask me how I want it written. Do not fall back on a general professional tone.]

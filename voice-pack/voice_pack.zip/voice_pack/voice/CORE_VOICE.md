# How [your name] writes

Loaded in every session. It holds only what is true of everything I write. What depends on the document is in that document's own guide.

## Me in two lines

[Your role and division, the countries you cover, and who reads most of what you write.]

## Constants

Each line is a habit, the reason for it, and a passage of mine that shows it. A habit with no passage does not belong here.

| What I do | Why | Where it shows |
|---|---|---|
| [habit] | [reason] | "[passage]" ([file]) |

## Which guide goes with which document

| Document | Guide in this folder |
|---|---|
| Email | `EMAIL_VOICE.md` |
| Memo or briefing note | none yet |
| Comments on a colleague's draft | none yet |
| Section of a Macroeconomic Assessment or Country Diagnostic | none yet |

Where the table says "none yet", draft from this file alone and tell me there is no guide for that document.

## Three checks before any draft

- The reader is known: who they are, and what they already know about the subject. If I did not say, ask.
- Every fact in the draft came from me. No praise, earlier conversation, date or promise is added to make the text friendlier or fuller.
- The draft is about as long as my samples of that document.

## Never in my writing

[Filled only from `log_voice_adjustments.md`. One line each, with the date of the correction it comes from.]

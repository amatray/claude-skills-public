# How [your name] writes [kind of document]

Copy this file once per kind of document and rename the copy, for example `MEMO_VOICE.md` or `COMMENTS_VOICE.md`. For sections of a Macroeconomic Assessment or a Country Diagnostic, use `HOUSE_STYLE_TEMPLATE.md`.

Read after `CORE_VOICE.md`, before drafting or editing [kind of document] for me. Built from my own documents in `corpus/[folder]`.

## Readers

| Reader | What they already know | What they will do with it | Length they will read |
|---|---|---|---|
| [for example, the Vice Presidency front office] | | | |

## Order of parts

[What comes first, second, last, when this document has a usual order. Left empty when the order changes each time.]

## Situations

One card for each situation I write in often. A card exists only if I have a real passage for it.

### [Situation]

- **Use when:**
- **Reader:**
- **The passage, exactly as written:**

> 

- **Why it is written this way:**
- **Belongs to that document only:** [figures, names and conclusions that must not be reused]

## My reasons

- I [habit], because [reason]. This holds for [which readers].

## No sample yet

[Situations my documents do not cover. For these, ask me.]

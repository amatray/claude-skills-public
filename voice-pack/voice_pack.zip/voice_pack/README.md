# Teaching Claude your voice: the homework package

In the session you taught Claude how you write emails. This package lets you finish that at your own pace, and then do the same for the other things you write, starting with your research papers.

Nothing here is graded and nothing is sent to anyone. Your emails and documents stay in a folder on your own laptop.

## What is in this folder

| File | What it is |
|---|---|
| `README.md` | This page. |
| `references/humanizer-rules.md` | Adrien's checklist of words, expressions and writing patterns to avoid. Optional reference, separate from your own voice guides. |
| `voice/CORE_VOICE.md` | Empty guide for what is true of everything you write. Claude fills it with you. |
| `voice/EMAIL_VOICE.md` | Empty guide for your emails: your readers, the situations you write in, your reasons. |
| `voice/GUIDE_TEMPLATE.md` | Empty guide to copy for a research paper, a memo, or comments on a draft. |
| `voice/HOUSE_STYLE_TEMPLATE.md` | Empty guide for sections of a Macroeconomic Assessment or a Country Diagnostic. |
| `voice/corrections.md` | The record of every draft you corrected. |
| `voice/corpus/emails/` | Where your sample emails go. Its `README.md` is a table Claude fills. |
| `skills/voice-learn-idb/` | A short skill: records what you changed in a draft. You install it in step B8. |
| `skills/voice-update-idb/` | A short skill: moves the corrections you agreed to into your guides. |

The `voice` folder is the pack. The `skills` folder holds the two routines that keep it improving. Everything else is instructions.

---

# Part A: the idea, in one page

## A1. How Claude reads your voice

Claude does not learn your voice. It does not remember your last conversation, and nothing you type changes the model. At the start of every session it reads a small set of text files, and what is written there is all it knows about you.

One of those files is your personal `CLAUDE.md`. It sits in the `.claude` folder of your home folder and is read in every session, whatever folder you have open. The pack works by putting your guides in a `voice` folder next to it, and adding a short section to it that loads your core guide and your email guide.

So the chain is short: every session reads your personal `CLAUDE.md`, which loads your core guide from that `voice` folder, which says which other guide to open for a memo or a report section.

Two consequences:

- If a preference is not written in the pack, it does not exist for Claude.
- Claude treats these files as guidance, not as a lock. A short guide with real examples is followed more reliably than a long list of rules.

## A2. Why word bans have a limited effect

When a person is told "never write *delve*", they rethink the sentence. Claude does not. It produces the next most likely word, which is usually a close synonym, and the sentence keeps the same shape. The word was a symptom. The cause was that Claude was writing for a generic reader, in a generic situation.

In our own test, none of the twelve drafts we collected contained a word from the usual ban lists. They still read as machine-written, because of their length, their opening line, and a paragraph offering the reader a way out.

A list can still help you spot expressions you want to remove. You can use my checklist in `references/humanizer-rules.md`. It covers writing patterns as well as words; examples of your own writing are still needed to teach Claude your voice. Paths mentioned inside the checklist refer to my own setup.

## A3. Show it, do not describe it

Describing your voice with adjectives makes things worse. In the same test, we asked for a reminder to a colleague who was two weeks late, with the same facts each time:

| Request | Length of the email | What happened |
|---|---|---|
| "Write an email." | 91 to 120 words (three tries) | Direct, opens with "Hi Carlos", no line about his wellbeing. |
| "Write a professional and friendly email." | 150 and 157 words (two tries) | "Dear Carlos", a line hoping he is well, and both times a sentence Carlos never said ("you mentioned it would be ready shortly"). |

What works, in order of importance:

- **Show.** Give two or three real passages you wrote for that kind of reader, and say who the reader was and what the text was for.
- **Explain why.** Give the reason behind a habit ("my director reads on her phone, so the request is in the first line"). A reason lets Claude handle cases a rule did not list.
- **Correct.** Keep Claude's draft next to your correction of it, so the difference is visible.

This is how you would brief a new assistant: a few of your emails, who the readers are, and your marks on their first drafts.

A list of words you do not use comes last, stays short, and contains only words you have actually removed from a draft.

---

# Part B: finish the email guide

Skip the steps you completed in the session. About an hour from the start.

## B0. Where you type

Use **Claude inside Visual Studio Code**, not the Claude website and not the Claude desktop app. Only the first can open the files on your laptop.

- Unzip the package first. On Windows, right-click `voice_pack.zip` and choose **Extract All**; a zipped folder that is only double-clicked looks open, but Claude cannot write in it.
- Move the unzipped `voice_pack` folder to a place you will keep, for example your Documents folder.
- Open Visual Studio Code. Click **File**, then **Open Folder**, and choose the `voice` folder inside `voice_pack`.
- You stay in this `voice` folder for every step below. You never open another folder. In step B6 your guides move to a second `voice` folder, inside `.claude`; Claude finds them there by itself.
- Several steps ask you to **start a new conversation**: click the speech bubble with a plus sign at the top right of the Claude panel. The box is empty and Claude remembers nothing of what came before. You do not close Visual Studio Code.
- Click the Claude Code icon at the top right to open the Claude panel. Every prompt below is typed in that panel.

**What correct looks like:** the left side of the window lists `CORE_VOICE.md`, `EMAIL_VOICE.md`, `corpus` and the other files.

## B1. Put your 20 emails in the folder

Put the 20 emails you collected into `corpus/emails`, in whatever form you have them: one file per email under any name, or all of them pasted one after the other into a single file. Then paste this in the Claude panel:

```text
The folder corpus/emails holds emails I sent, either one per file or several pasted into one file. Make one plain text file per email, named 01.txt, 02.txt and so on, in that same folder. In each file keep the "To" line, the subject line and the text I wrote, word for word. Remove the earlier messages quoted below my text, and remove legal disclaimers. Do not correct, shorten or reword anything I wrote. Do not touch README.md. When the numbered files are written, delete the files I gave you. Then show me a table with one row per email: the file name, the recipient, the subject, the number of sentences, and a flag on any email shorter than four sentences or that looks like a duplicate.
```

**What correct looks like:** 20 files, `01.txt` to `20.txt`, each containing only words you typed, and a table listing them.

If the table flags an email as too short, replace it with a longer one and paste the prompt again. If an email in the folder was drafted with AI, replace it too: otherwise the pack learns Claude's voice, not yours.

## B2. Make the "before" draft

This gives you something to compare with at the end. Paste this in the Claude panel:

```text
Write a professional and friendly email. Carlos in the fiscal division promised the fiscal section of the Panama report two weeks ago and has not sent it. I need it by Friday. Save the email as before.txt in this folder.
```

**What correct looks like:** a file `before.txt` appears on the left. Read it once. Do not fix it.

## B3. Let Claude guess who each email was for

```text
Read every file in corpus/emails. Fill the table in corpus/emails/README.md, one row per email: the recipient, your best guess of my relationship to them (senior, peer, junior, outside the Bank), and the purpose in a few words. Mark every guess as "guessed". Do not analyse my style yet. Then show me the table and ask me to correct it.
```

Read the table and correct it in plain words, for example "Carlos in row 4 is my director, not a peer". Claude cannot know the relationship from a name, and the relationship is what explains why two of your emails sound different.

**What correct looks like:** the table is filled, and the rows you corrected now say "confirmed".

## B4. Ask how you write, with evidence

```text
Using the emails in corpus/emails and the corrected table, tell me how I write emails. Give at most ten observations. For each one, quote two passages from different emails that show it, with the file names. Sort them into three groups: habits that hold for every recipient, habits that change with the recipient, and things that appear only once or twice and may be accidents. Cover length, how I open, how I ask for something, how I close and how formal I am before any remark on individual words. Do not write any guide yet. Ask me which observations are right.
```

Now check its reading. Some of what it found is a real habit. Some is an accident of 20 emails. Tell it which is which: "3 is right", "5 is wrong, that was one unusual email", "you missed that I never open with small talk".

**What correct looks like:** every observation comes with quotes you recognise as yours.

**What wrong looks like:** adjectives with no quotes ("your tone is warm and professional"). Reply: "Quote the passages or drop the observation."

## B5. Build the two guides

```text
Fill in CORE_VOICE.md and EMAIL_VOICE.md from the observations I confirmed, and from nothing else. In EMAIL_VOICE.md: complete the Readers table for the kinds of people I actually write to and delete the other rows. Fill one situation card for each situation where I have a real email, with the email exactly as I sent it, and delete the cards I have no email for. For each habit, write my reason, and ask me when you do not know it. In CORE_VOICE.md, put only what holds for every reader, with the passage that shows it. Leave a blank wherever my emails do not decide. Keep CORE_VOICE.md under 40 lines. Show me both files.
```

Claude will ask you for reasons: why you put the request first, why you sign off the way you do. Answer in a sentence. The reasons are what let it handle a situation that has no card.

Open both files and read them. They are yours: edit any line directly.

**What correct looks like:** a new assistant handed `EMAIL_VOICE.md` could write a reminder to a sector division that you would recognise as yours.

## B6. Make the pack the default

> **Everyone does this step. The only choice is how: Prompt 1 or Prompt 2 below.**

Until this step, the pack only works when this folder is open. This step makes it work everywhere, in two moves:

- Your guides move to a folder called `voice` inside the `.claude` folder of your home folder. That folder is the same whatever you have open, so there is one version of each guide and Claude always knows where it is.
- Your personal `CLAUDE.md`, which sits in that same `.claude` folder, gets a short section that says which guide goes with which document.

Your sample emails stay where they are, in the folder you have open.

There are two prompts. Both move the guides. They differ in how Claude gets to them afterwards. Use one of them, not both. With either, Claude asks for permission to write in the `.claude` folder, because that folder holds its own settings. Allow it.

| | Prompt 1: read when you write | Prompt 2: loaded in every session |
|---|---|---|
| What your `CLAUDE.md` holds | A table: which guide to read for which document | The same table, plus two lines starting with `@` |
| When Claude reads the guides | When you ask it to write something | At the start of every conversation |
| What it costs | Claude can skip the reading; you check with one question | The guides take room in every conversation, including those with no writing |

**Prompt 1: read when you write.**

```text
I want my voice guides kept in one place and used whenever I ask you to write, whatever folder is open. I do not want them loaded in every session. Do the following, in this order.

1. Create a folder called voice inside the .claude folder of my home folder. If it already exists and holds files, stop and tell me.

2. Copy into it, from this folder: CORE_VOICE.md, EMAIL_VOICE.md, corrections.md, GUIDE_TEMPLATE.md, HOUSE_STYLE_TEMPLATE.md and any other file whose name ends in _VOICE.md. Leave the corpus folder and every other file here. Check that each copy is identical to its original, then delete those originals from this folder, so that only one version of each guide exists.

3. Edit my personal CLAUDE.md, the one inside the .claude folder of my home folder, and create it if it is missing. Do not change or remove anything already in it. If something there disagrees with my guides, stop and show me both. At the end of the file, add exactly this section, and do not add any line starting with @:

## My writing voice

My voice guides are in ~/.claude/voice/. They say how I write. Before drafting or editing anything I will send or sign, open and read the guides in the row that matches, then tell me in one line which files you read.

| What I ask for | Guides to read first |
|---|---|
| Email or chat message | ~/.claude/voice/CORE_VOICE.md and ~/.claude/voice/EMAIL_VOICE.md |
| Any other document | ~/.claude/voice/CORE_VOICE.md, then the guide its table names for that document, in ~/.claude/voice/ |

For a task with no writing in my name, do not open these files.

New guides and corrections are saved in ~/.claude/voice/ and nowhere else.

4. When you are done, list the files now in that voice folder, print the section you added, and print the full path of both.
```

**What correct looks like:** Claude lists `CORE_VOICE.md`, `EMAIL_VOICE.md` and `corrections.md` in a folder whose path ends in `.claude/voice`, and prints a section with a table and no line starting with `@`. On the left of your window, those files are gone and `corpus` is still there.

Now check that Claude reads them. Start a new conversation and paste:

```text
Write a two-line email telling a colleague I will be ten minutes late to our meeting. Before the email, tell me which files you read.
```

**What correct looks like:** it names `CORE_VOICE.md` and `EMAIL_VOICE.md` before the email. If it names no file, tell Claude: "You did not read my voice guides. Read the section My writing voice in my personal CLAUDE.md and tell me why." If this happens again on later days, switch to Prompt 2: ask Claude "Add the two @ lines for my voice guides to the section My writing voice in my personal CLAUDE.md."

**Prompt 2: loaded in every session.**

```text
I want my voice guides kept in one place and loaded in every Claude session on this laptop, whatever folder is open. Do the following, in this order.

1. Create a folder called voice inside the .claude folder of my home folder. If it already exists and holds files, stop and tell me.

2. Copy into it, from this folder: CORE_VOICE.md, EMAIL_VOICE.md, corrections.md, GUIDE_TEMPLATE.md, HOUSE_STYLE_TEMPLATE.md and any other file whose name ends in _VOICE.md. Leave the corpus folder and every other file here. Check that each copy is identical to its original, then delete those originals from this folder, so that only one version of each guide exists.

3. Edit my personal CLAUDE.md, the one inside the .claude folder of my home folder, and create it if it is missing. Do not change or remove anything already in it. If something there disagrees with my guides, stop and show me both. At the end of the file, add exactly this section:

## My writing voice

My voice guides are in ~/.claude/voice/. They say how I write. Before drafting or editing anything I will send or sign, read the guides in the row that matches.

@~/.claude/voice/CORE_VOICE.md
@~/.claude/voice/EMAIL_VOICE.md

| What I ask for | Guides to read first |
|---|---|
| Email or chat message | CORE_VOICE.md and EMAIL_VOICE.md, both loaded by the two lines above |
| Any other document | CORE_VOICE.md, then the guide its table names for that document, in ~/.claude/voice/ |

New guides and corrections are saved in ~/.claude/voice/ and nowhere else.

4. When you are done, list the files now in that voice folder, print the section you added, and print the full path of both.
```

Claude will ask for permission to write in the `.claude` folder, because that folder holds its own settings. Allow it.

**What correct looks like:** Claude lists `CORE_VOICE.md`, `EMAIL_VOICE.md` and `corrections.md` in a folder whose path ends in `.claude/voice`, and prints a section with two lines starting with `@`. On the left of your window, those files are gone and `corpus` is still there.

From now on your guides are in that folder. To read or edit one, ask Claude "show me where my email guide is" and click the file name in its answer.

Now check that it loads. Start a new conversation and paste:

```text
Without opening any file: is my core voice guide already loaded in this session? If yes, quote its first heading and one line from it.
```

**What correct looks like:** it quotes your guide. If it says nothing is loaded, tell Claude: "The import in my personal CLAUDE.md does not load. Check the path and fix it."

## B7. Make the "after" draft

Start a new conversation. Give it the plain facts, with no adjectives:

```text
Write an email. Carlos in the fiscal division promised the fiscal section of the Panama report two weeks ago and has not sent it. I need it by Friday. Save the email as after.txt in this folder.
```

Compare with `before.txt`. Look at four things: the length, the first line, the way it asks, the sign-off. Then look for anything stated as fact that you did not tell it. A guide makes the draft sound like you; it does not check the facts. In our test the draft said the section "was due" two weeks ago, the wording of a sample email, where the request said "promised".

**What correct looks like:** close to the length of your own emails, opening and closing the way you do, with no invented praise or invented conversation.

## B8. Install the two skills

The pack gets good through corrections on real emails, not through this first version. Two short skills do the bookkeeping, so that a correction costs you one sentence.

A skill is a folder with one text file in it, `SKILL.md`, that tells Claude how to do one job. The two are in the `skills` folder of `voice_pack`, next to the `voice` folder you have open: each is about twenty lines. Claude finds a skill when it sits in the `skills` folder inside the `.claude` folder of your home folder.

In the Claude panel, paste:

```text
Go one level up from this folder: next to it there is a folder called skills. Install the two skills in it, voice-learn-idb and voice-update-idb. Copy each folder, unchanged, into the skills folder inside the .claude folder of my home folder, and create that skills folder if it does not exist. Then add two lines to my personal CLAUDE.md, the one inside that same .claude folder, without changing anything already in it: when I say "learn from my edits", use the voice-learn-idb skill, and when I say "update my guide", use the voice-update-idb skill. When you are done, list the folders in that skills folder and print the two lines you added.
```

Claude will ask for permission to read the `skills` folder and to write in the `.claude` folder, because that folder holds its own settings. Allow both. If Claude answers that it was blocked, reply: "Go ahead, I approve writing in the .claude folder."

**What correct looks like:** the list contains `voice-learn-idb` and `voice-update-idb`, and Claude prints the two lines.

Now check that they load. Start a new conversation. Type a forward slash, `/`, in the box. A list of commands appears. Keep typing `voice`.

**What correct looks like:** `voice-learn-idb` and `voice-update-idb` are in the list. If they are not, close Visual Studio Code completely, open it again and retry.

## B9. Correct a draft, then say "learn from my edits"

Ask Claude for a real email you need to send. Edit its draft until it is the email you would send. Paste your final version in the Claude panel, then type:

```text
Learn from my edits.
```

Claude sorts each of your changes into one of three kinds and adds an entry to `corrections.md`:

- **One-off.** A date, a name, or a choice that belonged to that email. Nothing to change.
- **Already covered.** Your guide said it and the draft did not follow it. Nothing to add.
- **Would come back.** A choice about how you write. Claude shows the exact line it would add or replace in a guide and asks you yes or no.

**You do not have to explain your edits in advance.** For a change that would come back, Claude needs your reason, because every line of your guide carries its "because". If you gave none, it offers its best guess and asks you to confirm or correct it. Answer in a few words. A guess you have not confirmed is recorded as a guess, never as your reason.

If you do want to say why as you go, say it in terms of the reader. "Carlos is a peer, I would not thank him three times" teaches Claude something. "Make it less formal" does not.

**What correct looks like:** a new entry at the bottom of `corrections.md`, with each reason marked as yours or as Claude's guess, and no change in `CORE_VOICE.md` or `EMAIL_VOICE.md`. Claude says where `corrections.md` is: next to your guides.

**If nothing happens** when you type the sentence, type `/voice-learn-idb` instead. That calls the skill by its name.

## B10. Every so often, say "update my guide"

An entry in `corrections.md` is only a record. Claude does not read that file when drafting, so the next draft changes only when a line in a guide changes. That is this step.

When a few corrections are waiting, type:

```text
Update my guide.
```

Claude takes the corrections you said yes to, keeps a copy of the guide as it was in a `history` folder, changes the guide, and shows you each line before and after. It asks you about the ones still waiting for your answer.

**What correct looks like:** the lines shown before and after, a new file in a `history` folder next to your guides, and the entry in `corrections.md` marked with the guide it went into.

Most corrections are one-offs and never reach this step. That is how the guides stay short enough to be followed.

## B11. Make the capture automatic with hooks

> **Do this ONLY if you want corrections saved without having to ask. This is NOT mandatory.**

B9 works when you remember to say "learn from my edits". A hook removes that step. A hook is a small program that Claude Code runs by itself at fixed moments, for example each time you send a message. Claude does not decide whether to run it, so it cannot forget.

The prompt below asks Claude to build three hooks and install them:

- **Capture.** When your message reacts to a draft Claude wrote, the hook saves an entry in `corrections.md` before Claude answers.
- **Guard.** Claude cannot change a guide unless your message says "update my guide". A correction reaches a guide only through B10.
- **Reminder.** When a session starts, the hook counts the corrections still waiting.

Do B6 and B8 first. Then start a new conversation and paste:

```text
I want hooks in Claude Code that save my writing corrections by themselves and protect my voice guides. Read the Claude Code documentation on hooks first (https://code.claude.com/docs/en/hooks), then do the following, in this order.

1. Find my voice folder: the folder that holds CORE_VOICE.md and corrections.md. Look in the section "My writing voice" of my personal CLAUDE.md, the one inside the .claude folder of my home folder. If you cannot find it, ask me where it is and stop.

2. Check what can run a script on this laptop: Python or Node. Use one that is installed. If neither is, or if hooks are switched off by the settings of my organisation, stop and tell me. Install nothing.

3. Write one script, in a folder called hooks inside the .claude folder of my home folder. It does three things.

a. Capture. Each time I send a message, the script reads it. If the message reacts to a piece of writing from earlier in the same conversation (for example "too formal", "I would not say this", "rewrite", "shorter", "this sounds like AI", or a corrected version pasted back), the script itself adds an entry at the bottom of corrections.md, in the format that file already uses: the date, my message word for word as the reason, and the status "captured, not sorted". It then tells you to complete that entry with the voice-learn-idb skill once you have answered me: the text I rejected, the text I approved, and the kind of change. It never writes a text I did not write, and it ignores messages that are not from me, such as task notifications.

b. Guard. Before you edit or write any file in my voice folder whose name ends in _VOICE.md, the script checks my last message. It lets the edit through only if that message contains "update my guide". Otherwise it refuses and tells you to record the correction and wait for me. It blocks nothing else, and it does not prevent me from editing a guide by hand.

c. Reminder. When a session starts, the script counts the entries in corrections.md that are captured and not sorted, or agreed and not yet in a guide, and gives you the number. If it is above zero, tell me in one line in your first answer.

4. If the script fails for any reason, it must let my message and your action go through. A broken hook must never block my work.

5. Register the script in the settings.json file inside the .claude folder of my home folder. First save a copy of that file next to it. Add the hooks without changing or removing anything already there.

6. Test the three behaviours by running the script yourself with made-up inputs: a message that reacts to a draft, a message that does not, a guide edit with and without "update my guide", and a session start. Remove the test entries from corrections.md afterwards. Show me the result of each test.

7. Tell me the path of the script, print what you added to settings.json, and give me the one sentence to send you if I ever want all of this removed.
```

Claude will ask for permission several times, because it writes in the `.claude` folder and runs the script to test it. Allow it.

**What correct looks like:** five test results, each with the outcome you expect (saved, not saved, refused, allowed, a count), the path of one script, and the lines added to `settings.json`.

Now check it for real. Close Visual Studio Code completely and open it again, because hooks are read at start. Ask Claude for a short email, then reply "this is too formal, rewrite it".

**What correct looks like:** a new entry at the bottom of `corrections.md` with your sentence in it, and Claude completes it after rewriting. Then type "Add a line to my email guide saying I never open with a greeting": Claude answers that it cannot change the guide and that you have to say "update my guide".

The capture works from a list of words, so it misses some corrections and catches some messages that are not corrections. "Learn from my edits" still works for the first case. For the second, tell Claude "that entry is not a correction, remove it".

---

# Part C: the other kinds of writing

## C1. Start with your research papers

Make a folder `corpus/papers` inside the folder you have open. Put in it 3 to 5 of your papers, as PDF or Word files, under any name. Then start a new conversation and paste:

```text
The folder corpus/papers holds research papers I wrote. Read the abstract, the introduction and the conclusion of each one, and one results section. Then tell me how I write papers. Give at most ten observations. For each one, quote two passages from different papers, with the file name and the page. Cover how I open an introduction, how I state the question and the contribution, how I report a result, how I place the paper in the literature, and how long my sentences and paragraphs are, before any remark on individual words. Ask me which observations are right. When I have answered, find the folder that holds my CORE_VOICE.md: it is the one named in my personal CLAUDE.md, or this folder if nothing is named there. In that folder, copy GUIDE_TEMPLATE.md to ResearchPaper_VOICE.md and fill it from the observations I confirmed and from nothing else, with the passages exactly as I wrote them. Add ResearchPaper_VOICE.md to the table "Which guide goes with which document" in CORE_VOICE.md. Show me the new file.
```

Claude stops once, to ask which observations are right. Answer in plain words, as you did for the emails.

**What correct looks like:** a new file `ResearchPaper_VOICE.md` next to your other guides, where every habit comes with a passage you recognise as yours.

To test it, start a new conversation and ask for a paragraph of a paper you are working on, for example the opening paragraph of an introduction from your own notes. Correct it, paste your version, and say "learn from my edits" as in B9.

## C2. Other documents, the same way

For any other kind of document you write often, use the prompt of C1 and change three things: the folder name, the kind of document, and the name of the guide.

- **Memos and briefing notes to management**, in `corpus/memos`, with the guide `MEMO_VOICE.md`. The reader is senior and short of time, so the guide is mostly about what comes first and what is left out.
- **Comments on a colleague's draft**, in `corpus/comments`, with the guide `COMMENTS_VOICE.md`. Your habits here are very personal: how direct you are, whether you propose the replacement text.
- **Report sections** of a Macroeconomic Assessment or a Country Diagnostic. This one is different, and has its own template, `HOUSE_STYLE_TEMPLATE.md`. The voice is the institution's, not yours. The samples are final, approved reports, not your own drafts. The guide works section by section, and it separates what Claude drafts (description) from what you supply (every judgement). Only use reports you are allowed to open with Claude under the Bank's rules.

When a new guide exists, move anything that turned out to be true in every kind of writing up into `CORE_VOICE.md`, and delete it from the individual guides.

## Keeping the pack healthy

- Keep `CORE_VOICE.md` short. If it grows past a page, something in it belongs in one of the other guides.
- Prefer replacing a line to adding one.
- If a draft misses, ask three questions before adding a rule. Was the guide read (the check in B6)? Did the guide already say it? If Claude followed the guide and the draft got worse, is the line itself wrong? Only the last one calls for changing a line.
- Revisit a guide when your preferences change, or when a draft embarrasses you. There is no schedule.

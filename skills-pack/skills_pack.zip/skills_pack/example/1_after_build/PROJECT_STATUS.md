# Panama macro assessment — due 2026-12-18

## Next actions
- [ ] Draft the fiscal section — due 2026-12-01
- [ ] Update the debt table — due no date

## Waiting on others
- [ ] Carlos — fiscal projections — due 2026-11-03
- [ ] Statistics office — national accounts revision — due 2026-11-06
- [ ] owner unknown — pension data — due 2026-11-30

## Done
- none

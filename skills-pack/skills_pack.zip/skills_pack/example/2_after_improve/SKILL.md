---
name: project-status-idb
description: Use when the user says "set up my status page" or "what is late on my project", or otherwise asks to create, update, or read the one-page status of the project folder they have open — the deliverable and its date, their own next actions, and what they are waiting on from other people. Keeps a single PROJECT_STATUS.md in the project folder and reports how many working days late each item is.
argument-hint: "[project folder]"
---

# The status page

One file per project folder: `PROJECT_STATUS.md`. It answers two questions and
nothing else — what the user must do next, and what they are waiting on from
other people.

Everything on the page came from the user. Nothing on it was inferred, filled
in from context, or guessed.

## The one rule

**Never write an answer the user did not give.** Not a date, not an owner, not
a next action, not a deliverable. If a field is missing, the page says it is
missing: `no date`, `owner unknown`. A placeholder the user can see and correct
is right; a plausible invention is wrong, because it reads as true.

## Before you run anything

Read `gotchas.md`, in this skill's folder
(`~/.claude/skills/project-status-idb/gotchas.md`), before doing anything else
in this skill. Every run, including a plain read of the page.

## Then: which folder?

The page lives in the project folder the user has open. So:

- If no folder is open, stop and ask which project folder to use.
- If more than one plausible project folder is in play, or you are not sure
  which project the user means, stop and ask.

Do **not** search the filesystem for a candidate folder, and do not pick the
most-recently-touched directory. Ask.

## Asking

Only on the first run in a project — when `PROJECT_STATUS.md` does not exist
yet. Three questions, in this order:

1. What is the deliverable, and what is its date?
2. What are your next actions?
3. Who owes you what, and by when?

Rules for asking:

- **One question at a time.** Ask the first, wait for the answer, then ask the
  second. Do not batch them into one message.
- **Typed in the chat.** Plain questions in your message text. Never a
  multiple-choice prompt, never an options box, never AskUserQuestion. The
  answers are free text the user writes.
- Take what they give. If they skip the date, that is `no date`. If they name
  an item but no person, that is `owner unknown`. Do not re-ask to fill a gap
  the placeholder already handles, and do not offer suggested answers.

## The sequence

Ask → propose → stop → write. In full:

1. Ask the three questions, one at a time.
2. Show the full proposed text of `PROJECT_STATUS.md` in the chat.
3. **Stop and wait for the user's yes.** Do not write the file in the same
   turn as the proposal. If they ask for changes, show the revised text and
   wait again.
4. On their yes, write the file.

## If PROJECT_STATUS.md already exists

Never start over and never overwrite blind. Instead:

1. Read the existing page.
2. Ask the user what changed. (Typed in the chat, same as above.)
3. Show the changes you propose — what moves to Done, what is added, what dates
   or owners change — against the current page.
4. Wait for their yes, then write.

Existing lines the user did not mention stay exactly as they are.

## If the user only asks what is late

"What is late on my project" is a read. Read `PROJECT_STATUS.md`, answer in the
chat, and **change nothing** — no edit, no write, no tidy-up.

For every item in Next actions and in Waiting on others, say either:

- how many **working days late** it is, or
- `not due yet` if the due date is in the future or is today, or
- `no date` if it has no due date — an item with no date is never late.

**Never do the arithmetic yourself.** Lateness is always measured in working
days, and always by the script in this skill's folder. For each dated item,
run:

    python3 ~/.claude/skills/project-status-idb/workdays.py <due-date> <today>

and report the number it prints as `N working days late`. If it prints `0`, the
item is `not due yet`. Do not estimate, do not count in your head, and do not
convert calendar days — not even when the answer looks obvious.

What the script implements, for reference only: working days are Monday to
Friday; the due date itself is not counted; a public holiday on a weekday still
counts as a working day.

Order the answer most-late first. Items in Done are not reported.

## The file

One file, `PROJECT_STATUS.md`, in the project folder. Nothing else is written —
no log, no archive, no second file. (`workdays.py` and `gotchas.md` live in the
skill folder, not the project folder.)

Structure: first line is the deliverable and its date. Then exactly three
sections, in this order: Next actions; Waiting on others; Done.

```markdown
# <deliverable> — due <YYYY-MM-DD | no date>

## Next actions
- [ ] <action> — due <YYYY-MM-DD | no date>

## Waiting on others
- [ ] <who | owner unknown> — <what> — due <YYYY-MM-DD | no date>

## Done
- [x] <item> — <date finished, if known>
```

Keep the sections even when empty; write `- none` under an empty one so the
shape of the page stays visible.

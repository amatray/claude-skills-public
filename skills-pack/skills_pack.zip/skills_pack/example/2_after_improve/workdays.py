#!/usr/bin/env python3
"""Count working days (Mon-Fri) between two dates.

Usage:  python3 workdays.py <from-date> <to-date>      # YYYY-MM-DD

Counts the working days that have passed from <from-date> to <to-date>.
The from-date itself is NOT counted; the to-date IS counted. So to get how
many working days late an item is, pass the due date as <from-date> and
today as <to-date>.

Saturdays and Sundays are never counted. Public holidays are not tracked:
a holiday on a weekday counts as a working day.

Prints a single integer. If <to-date> is on or before <from-date>, prints 0
(nothing is late yet).
"""

import sys
from datetime import date, timedelta


def parse(s):
    try:
        y, m, d = (int(p) for p in s.split("-"))
        return date(y, m, d)
    except (ValueError, AttributeError):
        sys.exit("workdays.py: not a YYYY-MM-DD date: %r" % s)


def workdays_between(start, end):
    """Working days in (start, end] — start excluded, end included."""
    if end <= start:
        return 0
    count = 0
    day = start + timedelta(days=1)
    while day <= end:
        if day.weekday() < 5:  # Mon=0 .. Fri=4
            count += 1
        day += timedelta(days=1)
    return count


def main(argv):
    if len(argv) != 3:
        sys.exit("usage: python3 workdays.py <from-date> <to-date>  (YYYY-MM-DD)")
    print(workdays_between(parse(argv[1]), parse(argv[2])))


if __name__ == "__main__":
    main(sys.argv)

# Creating and improving skills: the homework package

In the session you changed one workshop skill, had Claude build a small new one, and had Claude improve it. This package lets you redo each step at your own pace, on your own laptop, and then apply the same three moves to your own work.

You never write a skill file by hand. You write a request, Claude writes the skill, and you check what it wrote. The requests are on this page, each in a grey box, ready to copy.

Nothing here is graded and nothing is sent to anyone.

## What is in this folder

| File | What it is |
|---|---|
| `README.md` | This page. |
| `example/1_after_build/` | What Claude produced in our own test: the skill file, and the status page it made. |
| `example/2_after_improve/` | The same skill after the fix: the skill file, the script, the failures file. |

The files in `example` are there to compare with, not to install. Your own files will look different, and that is normal: in two tests of the same request, Claude wrote a skill file of 82 lines once and 112 lines the other time. What must match is the behavior, which each step below describes under **What correct looks like**.

---

# Part A: the ideas, in one page

## A1. What a skill is

A skill is a folder with one text file in it, called `SKILL.md`. The file has a name, a description, and instructions in plain sentences. It lives in the `skills` folder, inside the `.claude` folder of your home folder.

A skill folder can hold four other things, all optional:

- `scripts`: code the skill runs.
- `references`: material the skill reads when it needs it.
- `templates`: the output format the skill uses.
- `gotchas.md`: the list of what has gone wrong before.

## A2. The description says what the skill does and when to use it

At the start of a session Claude reads only the name and the description of each skill. It opens the rest when the description matches what you asked. The description should state both what the skill does and when to use it, including the words you would really type.

## A3. Text or code

AI reads and interprets what you want. Code runs explicit rules: purely deterministic operations belong in scripts; interpretation stays with AI.

For example, a script can stop an analysis if firm-year identifiers are duplicated, enforce explicit authentication checks, verify that required operations have been completed, or count working days using a stated rule. AI handles questions such as "Is this paper relevant to my research?" and "What do these results mean?"

A deterministic check is only as good as the rule you gave it. You still check that the rule and its tests match what you want.

## A4. Four choices in the skill's instructions

These are four things to specify, not four steps that every skill must run:

- **Phases:** what happens in order, and where Claude must STOP and wait for approval.
- **Arguments:** options supplied after the skill name in `$ARGUMENTS`. Examples include `quick`, `depth:light/standard/deep`, `file:path/to/file`, `focus:dimension`, `dryrun`, and `help`. The skill must define what each supported option does; these are not automatic features. An example invocation is `/my-skill depth:deep file:report.md`.
- **Output format:** the file and headings the skill must produce.
- **Missing information:** whether to carry on or stop and ask.

For the status page, a missing due date can be written as "no date" without blocking the other entries. An unknown project folder means stop and ask which folder to use. Never invent a plausible answer to fill a gap.

## A5. Test in a new session

The session that made a change remembers the change. A new session only has the file. So every check below is done in a new conversation: click the speech bubble with a plus sign at the top right of the Claude panel. The new conversation does not contain the previous chat; the saved skill file must carry the instructions. You do not close Visual Studio Code.

---

# Part B: change a skill you already have

Skip the steps you completed in the session.

## B0. Where you type

Use **Claude inside Visual Studio Code**, not the Claude website and not the Claude desktop app. Only the first can open the files on your laptop.

- Unzip the package first. On Windows, right-click `skills_pack.zip` and choose **Extract All**; a zipped folder that is only double-clicked looks open, but files cannot be read from it properly.
- Drag the unzipped `skills_pack` folder into your **project folder**: the folder you open in Visual Studio Code for your work, where the workshop skills were installed.
- Open Visual Studio Code. Click **File**, then **Open Folder**, and choose that project folder. Do not open `skills_pack` itself: the workshop skills live in the project folder, and Claude only finds them when that folder is the one open.
- Click the Claude Code icon at the top right to open the Claude panel. Every request below is typed in that panel.
- To copy a request: select all the text in its grey box on this page, copy it, and paste it in the Claude panel.

**What correct looks like:** the left side of the window lists your own project files, and among them a `skills_pack` folder that opens to show `README.md` and `example`.

## B1. Add your own source to the literature skill

The literature skill searches in a fixed order. Its first step is a list of institutions: IDB publications, IMF working papers and Article IV selected issues, World Bank, CEPAL, CAF, central bank and ministry working papers, rating-agency actions. After those come the academic databases.

Choose one source you use that is **not** in that list. Copy the request below, replace the part in square brackets with your source, and paste the whole text.

```text
I want to change the literature-idb skill. Do not run the skill. First tell me which copy of it runs on this laptop and where it is. Look only in the skills folder inside the .claude folder of my home folder and of this project; do not search the rest of the laptop. If you find more than one copy, list them and ask me which one to edit. In the ladder of that copy, add [a source that is not in the list, for example: OECD Economic Surveys] to Tier 1, at the end of the list of institutions, just before the sentence "Then academic databases". Change nothing else. Show me the lines before and after, and wait for my yes before saving.
```

- Claude first tells you which copy of the skill runs on your laptop. If it finds more than one, it asks which to change: choose the one inside this project.
- If Claude says it finds no copy, the folder you have open is not the one where the workshop skills were installed. Open that folder (**File**, **Open Folder**) and paste the request again.
- It then shows you the line before and after. Read both.
- If the change is the one you asked for, type `yes`.
- Claude will ask for permission to write in the `.claude` folder, because that folder holds its own settings. It may ask more than once in the same step; allow it each time. If Claude answers that it was blocked, reply: "Go ahead, I approve writing in the .claude folder."

**What correct looks like:** one line changed. Your source is at the end of the list of institutions, just before "Then academic databases". Nothing else moved.

One thing to know: if the workshop skills are installed again later, this copy is replaced and your line is gone. Keep the sentence you added in a note so that you can paste the request again.

## B2. Check the change in a new session

Start a new conversation and paste:

```text
Read the literature-idb skill that runs on this laptop and list the Tier 1 sources in order. Look only in the skills folder inside the .claude folder of my home folder and of this project; do not search the rest of the laptop. Do not run the skill.
```

**What correct looks like:** Claude lists the sources in order, with yours last among the institutions. It does not run the skill.

You check by reading the file, not by running the skill, because the skill's report does not say which publishers it searched. A run would not show you the change.

## B3. Before changing any other skill

When you want a skill to behave differently and do not know where to start, ask first. Fill the two parts in square brackets and paste:

```text
Read the skill [name] and tell me where this behavior is decided: [the behavior]. Is it a file the skill reads, the text of the skill, or a script? Then propose the smallest change. Change nothing yet.
```

A behavior is decided in one of three places, from the cheapest to change to the most invasive:

| Where | What you change | Example |
|---|---|---|
| A file the skill reads | A file in your project. The skill is untouched. | The style file of the reminder skill, which says of itself: "This file is yours." |
| The text of the skill | Words in `SKILL.md`. | The list of sources you changed in B1. |
| A script | Code inside the skill. | The script that checks every citation in the literature skill. |

Start with the cheapest.

---

# Part C: build your own small skill

The skill keeps one status page for a project: what you do next, what you are waiting for from others, what is done.

## C0. Create PROJECT_INDEX.md separately

With your project folder open, paste:

```text
Draft PROJECT_INDEX.md for the project folder I have open. List the main files and folders, what each contains, and which versions are current. Mark anything uncertain rather than guessing.

Link to PROJECT_STATUS.md if it exists; otherwise mark it as not yet created. Do not move or rename any files. If an index already exists, propose changes to it instead.

Show me the proposed index and wait for my yes before writing it.
```

Read the proposed index and approve it only when the file locations and current versions are right. Uncertain versions should be marked uncertain, not guessed.

`PROJECT_INDEX.md` maps where files live and which versions are current. `PROJECT_STATUS.md` records the deliverable, next actions, what you are waiting for, and what is done. The index prompt creates the index directly; it does not create a skill. The `project-status-idb` skill in the next exercise neither creates nor requires the index.

**What correct looks like:** Claude shows a proposed index before saving. After your yes, `PROJECT_INDEX.md` appears. Existing files are not moved or renamed. If the status page does not exist yet, the index says so.

Next session: skills to **clean an existing folder** and correctly set up a **new project folder**.

## C1. Write your three lines first

The request that builds the skill is below. It has three parts in square brackets. Write them before you paste.

```text
Create a skill called project-status-idb. Save it as project-status-idb/SKILL.md in the skills folder inside the .claude folder of my home folder. Everything below describes what the skill does when I use it later. Do not start doing it now: only write the skill file.

Job: it keeps one status page for the project folder I have open, so I can see what I must do next and what I am waiting for from others.

When to use it: when I say "[your phrase to set up or update the page]" or "[your phrase to ask what is late]".

What to ask: the first time in a project, ask me three questions, one at a time, typed in the chat, never as a multiple-choice box: what the deliverable is and its date; what my next actions are; who owes me what and by when. Never fill in an answer I did not give.

Steps: ask, then show me the page you propose, then stop and wait for my yes, then write it. If PROJECT_STATUS.md already exists, never start over: read it, ask me what changed, show me the changes, and wait for my yes. When I only ask what is late, read the page and answer; change nothing. For each item, say how many days late it is, or "not due yet".

Output: one file, PROJECT_STATUS.md, in the project folder. First line: the deliverable and its date. Then three sections in this order: Next actions; Waiting on others (who, what, due date); Done.

When something is missing: if no folder is open, or you are not sure which project I mean, stop and ask; do not search for a folder. If a due date is missing, write "no date" and carry on. [your own line: one more thing the skill needs, and whether it carries on or stops without it]

When you are done, show me the full text of the skill file.
```

The three parts:

- **Your phrase to set up or update the page.** The words you would really type, for example "set up my status page".
- **Your phrase to ask what is late.** For example "what is late on my project". Do not use "what am I waiting on": another workshop skill already uses that phrase.
- **Your own line for a missing piece.** Choose one more thing the skill needs, and say whether it carries on or stops without it (see A4). For example: "If I do not say who owes an item, write 'owner unknown' and carry on."

## C2. Paste the request

Paste the whole text of C1, with your three lines in it. Claude will ask for permission to write in the `.claude` folder, because that folder holds its own settings. It may ask more than once in the same step; allow it each time. If Claude answers that it was blocked, reply: "Go ahead, I approve writing in the .claude folder."

**What correct looks like:** Claude writes one file, `project-status-idb/SKILL.md`, and shows you its full text. It does **not** start asking you about a project. The first paragraph of the request is there for that reason: it separates building the skill from using it.

## C3. Read what Claude wrote and find your sentences

Reading the file is how you check the build. Look for three things in the text Claude showed you:

- your two phrases, in the description near the top;
- a place where the skill stops and waits for your yes before writing;
- your line for the missing piece.

For each one, ask yourself: is it there, and did it keep its meaning? If Claude added something you did not ask for, ask it why.

To see what a finished one looks like, open the `example` folder of this package, then `1_after_build`, then `SKILL.md`. That is the skill file Claude wrote when we ran this same request ourselves. Yours will not be word for word the same.

## C4. Use it, in a new session

Stay in your project folder. Start a new conversation. Type the phrase you wrote in C1 to set up the page, for example "set up my status page". If nothing happens, type `/project-status-idb`.

When Claude asks who owes you what, include at least one item whose date has already passed. You need it for the check in D3.

If the folder already contains a `PROJECT_STATUS.md`, Claude does not ask the three questions: it reads the page and asks what changed. That is the skill doing what you asked. To see the three questions, use a folder that has no such file yet.

**What correct looks like:**

- Claude asks three questions, one at a time: the deliverable and its date, your next actions, who owes you what and by when.
- It shows you the page it proposes and waits.
- After your `yes`, a file `PROJECT_STATUS.md` appears in your project folder, with the deliverable on the first line and three sections: Next actions, Waiting on others, Done.
- A date you did not give is written "no date". Nothing is invented.

An example of the page is in `example/1_after_build/PROJECT_STATUS.md`. The dates and bullets in yours may be formatted differently.

## C5. If something is off

Ask Claude these four questions, in this order. Each one is a sentence you can type.

1. Did the skill run at all?
2. Which copy of the skill ran, and where is it?
3. Is my sentence in the skill file?
4. It is in the file. Why was it not followed?

The first three are fixed by changing the file, with the request in D4. The fourth is the limit of text: a written line is followed most of the time. When the rule matters, the remedy is a script, which is Part D.

## C6. Build a skill of your own

The request you pasted in C2 has six labelled parts. Those six labels are what you keep; the status page was one way of filling them.

| Label | What you write there |
|---|---|
| Job | One sentence: what the skill produces and what you use it for. |
| When to use it | The words you would really type to start it (A2). |
| What to ask | What the skill cannot know and has to ask you. |
| Steps | What it does, in order, and where it stops for your yes. |
| Output | Where the result goes and what it contains. |
| When something is missing | For each thing it needs: carry on, or stop and ask (A4). |

Below is the same request with every part left blank. Choose something you do the same way every week or every month, fill the square brackets, and paste it.

```text
Create a skill called [a short name, in lower case, with hyphens between words]. Save it as [the same name]/SKILL.md in the skills folder inside the .claude folder of my home folder. Everything below describes what the skill does when I use it later. Do not start doing it now: only write the skill file.

Job: [one sentence: what the skill produces, and what you use it for]

When to use it: when I say "[the words you would really type]" or "[a second way you might say it]".

What to ask: [what the skill cannot know and has to ask you]. Ask one question at a time, typed in the chat, never as a multiple-choice box. Never fill in an answer I did not give.

Steps: [what the skill does, in order]. Before it writes or changes a file, it shows me what it proposes, then stops and waits for my yes.

Output: [where the result goes and what it contains, for example: one file called ..., with these sections in this order: ...]

When something is missing: [for each thing the skill needs, one sentence: either "write that it is missing and carry on", or "stop and ask me; do not look for it"]. Never fill a gap with something plausible.

When you are done, show me the full text of the skill file.
```

Then do what you did for the status page: read what Claude wrote and find your sentences in it (C3), and use it in a new session (C4).

Start small. A skill that does one thing and asks one question is easier to check than one that does five.

**What correct looks like:** Claude writes one skill file and shows you its text. Each of your six parts is in it, with its meaning unchanged.

---

# Part D: improve the skill

## D1. Tell the skill how to count days late

The build request says "days late" without defining how to count. Claude may choose a definition without telling you.

Take an item due Friday, 6 November 2026, checked Monday, 9 November 2026. Excluding the due date and including the check date gives:

| Counting rule | Result |
|---|---|
| Calendar days | 3 days late |
| Working days, Monday to Friday | 1 working day late |

Neither definition is inherently correct. You must specify the one you want. This exercise chooses Monday to Friday, including public holidays that fall on weekdays. It is a simplified exercise rule, not a country-specific holiday calendar.

## D2. Put the rule in a script

Paste the whole request:

```text
Update project-status-idb to report working days late.

Count Monday to Friday, including weekday public holidays. Exclude the due date and include today.

1. Add workdays.py and require the skill to run it whenever it calculates lateness.
2. Test it:
   6 November 2026 to 9 November 2026: 1 working day.
   3 November 2026 to 24 November 2026: 15 working days.
3. Record the calendar-day mistake in gotchas.md. Tell the skill to read that file before running.

Show me the code, test results and proposed SKILL.md edits. Wait for my approval before installing the changes.
```

It asks for `workdays.py`, two tests, and a `gotchas.md` entry explaining the calendar-day mistake when working days were intended. The skill must read that file before running.

**What correct looks like, before approval:**

- Claude shows the code and proposed `SKILL.md` edits.
- The test from 6 November 2026 to 9 November 2026 returns **1 working day**.
- The test from 3 November 2026 to 24 November 2026 returns **15 working days**.
- Claude waits for approval before installing changes in the skill folder.

Read the counting rule and the tests before saying yes. Two passing tests check those cases; they do not prove every possible input is handled correctly. If you use a different counting rule, change the request and work out matching test answers before pasting it.

After approval, the skill folder should contain `SKILL.md`, `workdays.py`, and `gotchas.md`. The skill must run the script for lateness calculations rather than doing its own arithmetic. Examples are in `example/2_after_improve/`.

If Claude cannot run Python on your laptop, stop and send its reply to the address below. Do not install software without the Bank's permission.

## D3. Check it, in a new session

In the same project folder, start a new conversation. Type the phrase you wrote in C1 to ask what is late, for example "what is late on my project".

**What correct looks like:** each late item is given in working days. Claude runs the script to get the number, and it does not change the page.

If no item on your page is past its date, Claude gives no number and there is nothing to check. Type your phrase to update the page, add one item with a past date, then ask again.

One case may surprise you. An item due on a Friday and checked on the Saturday is zero working days late, so the skill says it is not late yet. That follows from the rule.

## D4. The same request, for any skill

Here is a shorter, general version of the request in D2, with three blanks:

```text
The skill [name] did [what happened]. I wanted [what should happen]. Read the skill and tell me where this is decided: a file it reads, its text, or a script. Propose the smallest change, and add one line to its gotchas.md naming the kind of failure. If the skill has no gotchas.md, create it and add a line to the skill telling it to read that file before it runs. Show me before and after, and wait for my yes.
```

It has four parts: what the skill did, what you wanted, where the behavior is decided, and one line added to the failures file, which the skill is told to read. Use it whenever a skill does something you did not want.

The failures file, `gotchas.md`, is the skill's memory. Two habits keep it useful: each line names the kind of failure, not the particular case; and a line is never deleted, because it is the reason a fix exists.

## D5. Every so often

Ask Claude to look across your skills: "Look through my skills and give me a short list of what is worth fixing, combining, or retiring. Give me an example for each suggestion before you change anything."

---

# Part E: two extensions, if you want to go further

Each extension adds a dependency. Specify whether the skill should carry on or stop when that dependency is unavailable.

- **Propose "Waiting on others" entries from email.** Marie writes "I'll send the figures by Friday." The skill proposes `Marie | Figures | Due Friday`, and waits for your approval before saving. The Bank must allow the email connection first.
- **Publish the page where your team can open it.** This also needs an approved connection to the place where it is published.

---

## If something does not work

Do not spend time repairing it. Copy what you typed and Claude's full reply into a text file, add one line saying which step of this page you were on, and email it to Adrien Matray at adrien.matray@gmail.com. We look at these after the session and send back a fix.

Two things have not been tested on Bank laptops: these steps on Windows, and the permission window that Visual Studio Code shows when Claude writes in the `.claude` folder. If either behaves differently from what this page describes, that is the first thing we want to hear about.
